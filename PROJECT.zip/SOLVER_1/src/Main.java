/*
Алгоритм построения минного поля и задания параметров взят из моей курсовой работы с графическим интерфейсом
 */
public class Main {
    public static void main(String[] args)
    {
        new Solution();
    }
}
